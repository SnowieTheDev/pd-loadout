fx_version 'cerulean'
games {'gta5'}

author 'Snowie Developments'
description 'Simple PD Weapons Loadout System W/ Notifications'
version '0.1'

client_scripts {
    'equippd.net.dll',
    'unequippd.net.dll',
    'ammo.net.dll'
}

server_scripts {
    'script_starter.lua'
}

other_scripts {
    -- N/A
}


-- ##############################
-- ##                          ##
-- ##   Snowie Developments    ##
-- ##    PD Loadout Script     ##
-- ##                          ##
-- ############################## 