## ############################## ##
## ##                          ## ##
## ##   Snowie Developments    ## ##
## ##    PD Loadout Script     ## ##
## ##                          ## ##
## ############################## ## 

### --- PD Loadout Script --- ###

*This is our first release! We realise there could be some issues so feel free to join the discord and tell us! That is the quickest way to get a response!*
**About The Script:** This script is a basic standalone script using text commands to equip a realistic PD loadout, you can unequip or refill ammo as needed as well!
**Testing:** The script has been tested and works fully with default FX servers (as we have seen in our testing of yet!), it is standalone so it should work with all other frameworks, however, we have not tested this.
**Thank you for the download!**


### --- Features --- ###

- Plug & Play
- Equip Loadout Command
- Unequip Loadout Command
- Refill Ammo Command
- Notifications Per Command


### --- Commands --- ###

- `/equippd` - Equips Basic PD Loadout (Includes: Combat Pistol, Taser, Flashlight, Carbine Rifle, Pump Shotgun)
- `/unequippd` - Unequips Basic PD Loadout
- `/refillammo` - Refills PD Loadout Ammo Counts (Does Not Add Ammo, Refils To The Ammout That Is Realistic!)


### --- Installation --- ###
#1. Drag into server resources folder
#2. Place `start pd-loadout` or `ensure pd-loadout` in your server.cfg
#3. Enjoy!


### --- Other Info --- ###

**If you have special requests you can ask in our discord!**
*We Plan To Be Adding Permissions Integration At Some Point!*


***Our Discord:*** https://discord.gg/bejHE2x



##    _____                     _         ____                 __                                 __      
##   / ___/____  ____ _      __(_)__     / __ \___ _   _____  / /___  ____  ____ ___  ___  ____  / /______
##   \__ \/ __ \/ __ \ | /| / / / _ \   / / / / _ \ | / / _ \/ / __ \/ __ \/ __ `__ \/ _ \/ __ \/ __/ ___/
##  ___/ / / / / /_/ / |/ |/ / /  __/  / /_/ /  __/ |/ /  __/ / /_/ / /_/ / / / / / /  __/ / / / /_(__  ) 
## /____/_/ /_/\____/|__/|__/_/\___/  /_____/\___/|___/\___/_/\____/ .___/_/ /_/ /_/\___/_/ /_/\__/____/                                    