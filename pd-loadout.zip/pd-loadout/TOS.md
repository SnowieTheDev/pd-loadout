## ############################## ##
## ##                          ## ##
## ##   Snowie Developments    ## ##
## ##           TOS            ## ##
## ##                          ## ##
## ############################## ## 

### --- TOS --- ###

DO NOT RIP FROM THE SCRIPT
DO NOT REUPLOAD
DO NOT CLAIM AS YOUR OWN
DO NOT EDIT THEN ASK FOR HELP
ANYTHING YOU WANT TO DO ASK FIRST!

WE ARE NOT RESPONSIBLE FOR ANY DAMAGES TO YOUR PC, SERVER OR ANY OTHER THINGS AFFECTED BY OUR SCRIPTS!



##    _____                     _         ____                 __                                 __      
##   / ___/____  ____ _      __(_)__     / __ \___ _   _____  / /___  ____  ____ ___  ___  ____  / /______
##   \__ \/ __ \/ __ \ | /| / / / _ \   / / / / _ \ | / / _ \/ / __ \/ __ \/ __ `__ \/ _ \/ __ \/ __/ ___/
##  ___/ / / / / /_/ / |/ |/ / /  __/  / /_/ /  __/ |/ /  __/ / /_/ / /_/ / / / / / /  __/ / / / /_(__  ) 
## /____/_/ /_/\____/|__/|__/_/\___/  /_____/\___/|___/\___/_/\____/ .___/_/ /_/ /_/\___/_/ /_/\__/____/                                    